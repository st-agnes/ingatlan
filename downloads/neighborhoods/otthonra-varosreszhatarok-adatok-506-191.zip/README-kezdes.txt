OTTHONRA – INGYENES MAGYAR VÁROSRÉSZHATÁROK

Kezdés
------
A ZIP-et bontsd ki egy tetszőleges könyvtárba. A könyvtárszerkezetet tartsd meg.

Egységes határvonalak (GeoJSON, WGS84/EPSG:4326):
  data/neighborhoods/neighborhoods.geojson
  data/neighborhoods/neighborhoods.geojson.gz

Városonkénti statisztikák és hiányok:
  data/neighborhoods/nationwide-report.csv
  data/neighborhoods/nationwide-report.md
  data/neighborhoods/nationwide-report.json

Külön kezelt tágabb tervezési egységek és nem hitelesített becsült jelöltek:
  data/neighborhoods/planning-units.geojson
  data/neighborhoods/estimated-candidates.geojson
  data/neighborhoods/estimated-report.csv
  data/neighborhoods/estimated-report.json

A becsült jelöltek városonkénti statisztikája külön mutatja a geometriai
rekordokat és a forrásneveket. Egy több részből álló alakzat egy rekord;
a történeti alternatívák és tágabb csoportok nem új, igazolt városrészek.

Külön kutatási forrásfelületek (nem városrészhatárok):
  data/neighborhoods/sources/extra-osm-candidates/landuse-proxies.geojson
  data/neighborhoods/sources/public-vector-next/wof-alt/

Az országos leltár 3155 települése nem jelenti az összes városrész ismeretét.
A forrásalapú, a tervezési és a becsült rétegek nem összeadhatók teljes
városrész-lefedettségként; a becslések nem zárják le a hiánylistát.

Önálló, internet nélkül is megnyitható alakzatnézegető:
  data/neighborhoods/review.html

Részletes dokumentáció, módszertan, licencek:
  docs/NEIGHBORHOOD-DATA.md
  data/neighborhoods/sources/

A források, forrásdátumok, névellenőrzések és hiányok megmaradnak az adatok
mellett. Az adatgyűjtemény nem teljes országos városrésznyilvántartás.

Offline újraépítés
-----------------
A kibontott könyvtár gyökerében futtasd. Node.js 22 vagy újabb és Python 3 szükséges;
Git, MySQL, backend, npm-telepítés és hálózati hozzáférés nem szükséges.

  node scripts/neighborhoods/build.mjs
  node scripts/neighborhoods/report.mjs
  node scripts/neighborhoods/export.mjs
  node scripts/neighborhoods/export-secondary.mjs
  node scripts/neighborhoods/nationwide-report.mjs
  python3 scripts/neighborhoods/combined-report.py
  node scripts/neighborhoods/preview.mjs

Ellenőrzés:

  node scripts/neighborhoods/build.mjs --check
  node scripts/neighborhoods/report.mjs --check
  node scripts/neighborhoods/export.mjs --check
  node tests/neighborhoods.test.mjs
  node tests/neighborhoods-osm.test.mjs
  node tests/neighborhoods-national.test.mjs
  node tests/neighborhoods-report.test.mjs
  node tests/neighborhoods-fetch.test.mjs
  node tests/neighborhoods-manual.test.mjs
  node tests/neighborhoods-semantic.test.mjs
  node tests/neighborhoods-country.test.mjs
  node tests/neighborhoods-nationwide-report.test.mjs

Az eredeti budapesti shapefile-ok köztes konverziója külön, Python 3-mal:

  python3 data/neighborhoods/sources/national-osm/convert.py
  python3 data/neighborhoods/sources/national-osm-2025/convert.py

Újracsomagolás Python 3-mal (nem építi újra és nem tölti le az adatokat):

  python3 scripts/neighborhoods/package.py --output csomag

Integritás
----------
A SHA256SUMS.txt a csomag minden más fájljának SHA256-lenyomatát tartalmazza.
Linuxon ellenőrizhető a kibontás után: sha256sum -c SHA256SUMS.txt
macOS-en: shasum -a 256 -c SHA256SUMS.txt
A csomagoló minden ZIP-bejegyzést visszaolvas, ellenőrzi a CRC-t és az SHA256-ot.
A böngészős automatizált teszt külön Playwright-környezetet igényel; az adatok
megtekintéséhez és a fenti offline ellenőrzésekhez nem szükséges.
